<?= $this->include('template/header'); ?>
<h1>Tampilan Home Awal</h1>
<?= $this->include('template/footer'); ?>